package com.ijktech.bytegpt

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.nio.channels.Channels

class ByteGPTDownloader(private val context: Context) {
    companion object {
        private const val TAG = "ByteGPTDownloader"
        private const val MODELS_DIR = "bytegpt_models"
        private const val TOKENIZERS_DIR = "bytegpt_tokenizers"
        
        // Model URLs
        const val MODEL_R1_URL = "https://huggingface.co/ijktech/ByteGPT-r1/resolve/main/model_mobile.ort?download=true"
        
        // Tokenizer URLs
        const val TOKENIZER_JSON_URL = "https://huggingface.co/ijktech/ByteGPT-r1/resolve/main/tokenizer.json?download=true"
        const val TOKENIZER_CONFIG_URL = "https://huggingface.co/ijktech/ByteGPT-r1/resolve/main/tokenizer_config.json?download=true"
        const val SPECIAL_TOKENS_MAP_URL = "https://huggingface.co/ijktech/ByteGPT-r1/resolve/main/special_tokens_map.json?download=true"
    }

    private val modelsDir: File
    private val tokenizersDir: File

    init {
        modelsDir = File(context.filesDir, MODELS_DIR).apply { mkdirs() }
        tokenizersDir = File(context.filesDir, TOKENIZERS_DIR).apply { mkdirs() }
    }

    suspend fun downloadModel(modelUrl: String, modelName: String): File = withContext(Dispatchers.IO) {
        val modelFile = File(modelsDir, modelName)
        
        if (modelFile.exists()) {
            Log.d(TAG, "Model $modelName already exists, skipping download")
            return@withContext modelFile
        }
        
        Log.d(TAG, "Downloading model $modelName from $modelUrl")
        downloadFile(modelUrl, modelFile)
        Log.d(TAG, "Model $modelName downloaded successfully")
        
        return@withContext modelFile
    }

    suspend fun downloadTokenizerFiles(
        tokenizerJsonUrl: String = TOKENIZER_JSON_URL,
        tokenizerConfigUrl: String = TOKENIZER_CONFIG_URL,
        specialTokensMapUrl: String = SPECIAL_TOKENS_MAP_URL
    ): TokenizerFiles = withContext(Dispatchers.IO) {
        val tokenizerJsonFile = File(tokenizersDir, "tokenizer.json")
        val tokenizerConfigFile = File(tokenizersDir, "tokenizer_config.json")
        val specialTokensMapFile = File(tokenizersDir, "special_tokens_map.json")
        
        if (!tokenizerJsonFile.exists()) {
            Log.d(TAG, "Downloading tokenizer.json")
            downloadFile(tokenizerJsonUrl, tokenizerJsonFile)
        }
        
        if (!tokenizerConfigFile.exists()) {
            Log.d(TAG, "Downloading tokenizer_config.json")
            downloadFile(tokenizerConfigUrl, tokenizerConfigFile)
        }
        
        if (!specialTokensMapFile.exists()) {
            Log.d(TAG, "Downloading special_tokens_map.json")
            downloadFile(specialTokensMapUrl, specialTokensMapFile)
        }
        
        return@withContext TokenizerFiles(
            tokenizerJsonFile,
            tokenizerConfigFile,
            specialTokensMapFile
        )
    }

    private fun downloadFile(url: String, destination: File) {
        URL(url).openStream().use { input ->
            val readableByteChannel = Channels.newChannel(input)
            FileOutputStream(destination).use { fileOutputStream ->
                fileOutputStream.channel.transferFrom(readableByteChannel, 0, Long.MAX_VALUE)
            }
        }
    }

    data class TokenizerFiles(
        val tokenizerJson: File,
        val tokenizerConfig: File,
        val specialTokensMap: File
    )
} 