package com.ijktech.bytegpt

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.charset.StandardCharsets
import java.util.regex.Pattern

class ByteGPTBPETokenizer(
    private val context: Context,
    private val downloader: ByteGPTDownloader
) {
    companion object {
        private const val TAG = "ByteGPTBPETokenizer"
        private const val BOS_TOKEN = ""
        private const val EOS_TOKEN = ""
        private const val USER_TOKEN = ""
        private const val ASSISTANT_TOKEN = ""
    }

    private var tokenizerFiles: ByteGPTDownloader.TokenizerFiles? = null
    private var vocabulary: Map<String, Int> = emptyMap()
    private var merges: List<Pair<String, String>> = emptyList()
    private var specialTokens: Map<String, Int> = emptyMap()
    private var bosTokenId: Int = -1
    private var eosTokenId: Int = -1
    private var userTokenId: Int = -1
    private var assistantTokenId: Int = -1
    private var initialized = false

    fun getEosTokenId(): Int {
        if (!initialized) {
            throw IllegalStateException("Tokenizer not initialized. Call initialize() first.")
        }
        return eosTokenId
    }

    suspend fun initialize() = withContext(Dispatchers.IO) {
        if (initialized) return@withContext

        try {
            // Download tokenizer files if not already downloaded
            tokenizerFiles = downloader.downloadTokenizerFiles()
            
            // Parse tokenizer.json
            val tokenizerJson = JSONObject(tokenizerFiles!!.tokenizerJson.readText())
            
            // Load vocabulary
            val vocabObj = tokenizerJson.getJSONObject("model").getJSONObject("vocab")
            vocabulary = vocabObj.keys().asSequence().associate { key ->
                key to vocabObj.getInt(key)
            }
            
            // Load merges
            val mergesArray = tokenizerJson.getJSONObject("model").getJSONArray("merges")
            merges = (0 until mergesArray.length()).map {
                val merge = mergesArray.getString(it).split(" ")
                Pair(merge[0], merge[1])
            }
            
            // Load special tokens
            val addedTokens = tokenizerJson.getJSONArray("added_tokens")
            specialTokens = (0 until addedTokens.length()).associate {
                val token = addedTokens.getJSONObject(it)
                token.getString("content") to token.getInt("id")
            }
            
            // Get special token IDs
            bosTokenId = specialTokens[BOS_TOKEN] ?: -1
            eosTokenId = specialTokens[EOS_TOKEN] ?: -1
            userTokenId = specialTokens[USER_TOKEN] ?: -1
            assistantTokenId = specialTokens[ASSISTANT_TOKEN] ?: -1
            
            initialized = true
            Log.d(TAG, "Tokenizer initialized successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing tokenizer", e)
            throw e
        }
    }

    fun encode(text: String): List<Int> {
        if (!initialized) {
            throw IllegalStateException("Tokenizer not initialized. Call initialize() first.")
        }

        val tokens = mutableListOf<Int>()
        
        // Add BOS token
        tokens.add(bosTokenId)
        
        // Tokenize the text
        val words = text.split(Pattern.compile("\\s+"))
        for (word in words) {
            val wordTokens = tokenizeWord(word)
            tokens.addAll(wordTokens)
        }
        
        // Add EOS token
        tokens.add(eosTokenId)
        
        return tokens
    }

    fun encodeChat(userMessage: String, assistantMessage: String? = null): List<Int> {
        if (!initialized) {
            throw IllegalStateException("Tokenizer not initialized. Call initialize() first.")
        }

        val tokens = mutableListOf<Int>()
        
        // Add BOS token
        tokens.add(bosTokenId)
        
        // Add user message
        tokens.add(userTokenId)
        tokens.addAll(tokenizeText(userMessage))
        
        // Add assistant message if provided
        if (assistantMessage != null) {
            tokens.add(assistantTokenId)
            tokens.addAll(tokenizeText(assistantMessage))
            tokens.add(eosTokenId)
        }
        
        return tokens
    }

    fun decode(ids: List<Int>): String {
        if (!initialized) {
            throw IllegalStateException("Tokenizer not initialized. Call initialize() first.")
        }

        val result = StringBuilder()
        
        // Filter out special tokens and decode
        for (id in ids) {
            if (id == bosTokenId || id == eosTokenId || id == userTokenId || id == assistantTokenId) {
                continue
            }
            
            // Find the token for this ID
            val token = vocabulary.entries.find { it.value == id }?.key
            if (token != null) {
                // Replace underscore with space for subword tokens
                val decoded = token.replace("▁", " ")
                result.append(decoded)
            }
        }
        
        return result.toString().trim()
    }

    private fun tokenizeText(text: String): List<Int> {
        val tokens = mutableListOf<Int>()
        val words = text.split(Pattern.compile("\\s+"))
        
        for (word in words) {
            tokens.addAll(tokenizeWord(word))
        }
        
        return tokens
    }

    private fun tokenizeWord(word: String): List<Int> {
        // This is a simplified BPE tokenization
        // In a real implementation, you would apply the BPE algorithm with merges
        
        // For now, we'll just look up the word in the vocabulary
        val token = vocabulary[word]
        return if (token != null) {
            listOf(token)
        } else {
            // If the word is not in vocabulary, tokenize character by character
            word.map { char ->
                vocabulary[char.toString()] ?: vocabulary["<unk>"] ?: 0
            }
        }
    }
} 