package com.ijktech.bytegpt

import android.content.Context
import android.os.Debug
import android.util.Log

class ByteGPTMemoryManager(private val context: Context) {
    companion object {
        private const val TAG = "ByteGPTMemoryManager"
        
        fun getAvailableMemory(): Long {
            val runtime = Runtime.getRuntime()
            return runtime.maxMemory() - (runtime.totalMemory() - runtime.freeMemory())
        }
        
        fun forceGarbageCollection() {
            System.gc()
            System.runFinalization()
            System.gc()
        }
        
        fun isMemorySufficient(requiredMemory: Long): Boolean {
            return getAvailableMemory() > requiredMemory
        }
    }
} 