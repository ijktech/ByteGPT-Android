package com.ijktech.bytegpt

import android.content.Context
import android.util.Log
import ai.onnxruntime.*

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.nio.LongBuffer
import java.nio.channels.FileChannel

class ByteGPTGenerator(
    private val context: Context,
    val modelType: ModelType = ModelType.BYTE_MODEL,
    private val maxLength: Int = 512
) {
    companion object {
        private const val TAG = "ByteGPTGenerator"
        private const val BYTE_MODEL_NAME = "byte_model.ort"
        private const val R1_MODEL_NAME = "model_mobile.ort"
    }

    enum class ModelType {
        BYTE_MODEL,  // Original ByteGPT model
        R1_MODEL     // New R1 model
    }

    private val env = OrtEnvironment.getEnvironment()
    private var session: OrtSession? = null
    private val downloader = ByteGPTDownloader(context)
    
    // Tokenizers
    private val byteTokenizer = ByteGPTTokenizer()
    private val bpeTokenizer = ByteGPTBPETokenizer(context, downloader)
    
    private var initialized = false

    suspend fun initialize() = withContext(Dispatchers.IO) {
        if (initialized) return@withContext

        try {
            // Download and load the appropriate model
            val modelFile = when (modelType) {
                ModelType.BYTE_MODEL -> {
                    // For the original model, we might load from assets
                    loadModelFromAssets(BYTE_MODEL_NAME)
                    null
                }
                ModelType.R1_MODEL -> {
                    // For the R1 model, download it
                    val file = downloader.downloadModel(ByteGPTDownloader.MODEL_R1_URL, R1_MODEL_NAME)
                    
                    // Force garbage collection before loading the model
                    System.gc()
                    
                    file
                }
            }

            // Initialize the session
            if (modelType == ModelType.BYTE_MODEL) {
                // Session already initialized in loadModelFromAssets
            } else {
                // Try to use memory-mapped file access instead of loading the whole model
                try {
                    // Create session with file path instead of loading bytes
                    session = env.createSession(modelFile!!.path)
                } catch (e: Exception) {
                    Log.e(TAG, "Error creating session with file path, falling back to byte array", e)
                    
                    // Force garbage collection before loading
                    System.gc()
                    
                    // Fall back to loading the model in chunks
                    val fileSize = modelFile!!.length()
                    Log.d(TAG, "Model file size: $fileSize bytes")
                    
                    // If the file is too large, we might need to use a different approach
                    if (fileSize > 500 * 1024 * 1024) { // If larger than 500MB
                        Log.d(TAG, "Large model detected, using chunked loading")
                        
                        // Load the model in chunks to avoid OOM
                        val fileInputStream = FileInputStream(modelFile)
                        val channel = fileInputStream.channel
                        
                        // Use a smaller buffer size to avoid OOM
                        val bufferSize = 10 * 1024 * 1024 // 10MB chunks
                        val modelBytes = ByteArray(fileSize.toInt())
                        var position = 0L
                        
                        while (position < fileSize) {
                            // Calculate remaining bytes
                            val remaining = fileSize - position
                            val currentChunkSize = minOf(bufferSize.toLong(), remaining).toInt()
                            
                            // Map a portion of the file
                            val buffer = channel.map(
                                FileChannel.MapMode.READ_ONLY,
                                position,
                                currentChunkSize.toLong()
                            )
                            
                            // Copy to our byte array
                            buffer.get(modelBytes, position.toInt(), currentChunkSize)
                            
                            // Update position
                            position += currentChunkSize
                            
                            // Force garbage collection after each chunk
                            System.gc()
                        }
                        
                        // Close resources
                        channel.close()
                        fileInputStream.close()
                        
                        // Create session with the loaded bytes
                        session = env.createSession(modelBytes)
                    } else {
                        // For smaller models, we can load the bytes directly
                        session = env.createSession(modelFile.readBytes())
                    }
                }
            }

            // Initialize the BPE tokenizer if using R1 model
            if (modelType == ModelType.R1_MODEL) {
                bpeTokenizer.initialize()
            }

            initialized = true
            Log.d(TAG, "Generator initialized with model type: $modelType")
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing generator", e)
            throw e
        }
    }

    private fun loadModelFromAssets(modelName: String) {
        context.assets.open(modelName).use { modelInput ->
            val modelBytes = modelInput.readBytes()
            session = env.createSession(modelBytes)
        }
    }

    suspend fun generate(
        prompt: String,
        maxNewTokens: Int = 50,
        temperature: Float = 1.0f
    ): String = withContext(Dispatchers.Default) {
        if (!initialized) {
            throw IllegalStateException("Generator not initialized. Call initialize() first.")
        }

        when (modelType) {
            ModelType.BYTE_MODEL -> generateWithByteModel(prompt, maxNewTokens, temperature)
            ModelType.R1_MODEL -> generateWithR1Model(prompt, maxNewTokens, temperature)
        }
    }

    private fun generateWithByteModel(
        prompt: String,
        maxNewTokens: Int,
        temperature: Float
    ): String {
        var currentIds = byteTokenizer.encode(prompt)

        for (i in 0 until maxNewTokens) {
            if (currentIds.size >= maxLength) break

            val shape = longArrayOf(1, currentIds.size.toLong())
            val tensorInput = OnnxTensor.createTensor(env, LongBuffer.wrap(currentIds), shape)

            val output = session!!.run(mapOf("input" to tensorInput), setOf("output"))
            // Convert float[][][] to Float[][][]
            @Suppress("UNCHECKED_CAST")
            val rawLogits = output[0].value as Array<Any>
            val logits = rawLogits.map { it as Array<FloatArray> }.toTypedArray()

            // Get logits for the last token
            val lastTokenLogits = logits[0].last()
            if (temperature != 1.0f) {
                for (j in lastTokenLogits.indices) {
                    lastTokenLogits[j] /= temperature
                }
            }

            val expLogits = lastTokenLogits.map { Math.exp(it.toDouble()) }
            val sum = expLogits.sum()
            val probs = expLogits.map { it / sum }

            val random = Math.random()
            var cumsum = 0.0
            var nextToken = 0
            for (j in probs.indices) {
                cumsum += probs[j]
                if (random < cumsum) {
                    nextToken = j
                    break
                }
            }

            currentIds = currentIds.plus(nextToken.toLong())
            if (nextToken.toLong() == ByteGPTTokenizer.EOS_ID) break
        }

        return byteTokenizer.decode(currentIds)
    }

    private fun generateWithR1Model(
        prompt: String,
        maxNewTokens: Int,
        temperature: Float
    ): String {
        // Encode the prompt using BPE tokenizer
        val inputIds = bpeTokenizer.encode(prompt)
        
        // Convert to LongArray for ONNX
        var currentIds = inputIds.map { it.toLong() }.toLongArray()
        val generatedIds = mutableListOf<Int>()
        
        for (i in 0 until maxNewTokens) {
            if (currentIds.size >= maxLength) break

            val shape = longArrayOf(1, currentIds.size.toLong())
            val tensorInput = OnnxTensor.createTensor(env, LongBuffer.wrap(currentIds), shape)

            val output = session!!.run(mapOf("input_ids" to tensorInput), setOf("logits"))
            // Convert to appropriate type
            @Suppress("UNCHECKED_CAST")
            val logits = output[0].value as Array<Array<FloatArray>>

            // Get logits for the last token
            val lastTokenLogits = logits[0].last()
            
            // Apply temperature
            if (temperature != 1.0f) {
                for (j in lastTokenLogits.indices) {
                    lastTokenLogits[j] /= temperature
                }
            }

            // Sample from the logits
            val nextToken = sampleFromLogits(lastTokenLogits, temperature)
            generatedIds.add(nextToken)
            
            // Check for EOS token
            if (nextToken == bpeTokenizer.getEosTokenId()) break
            
            // Update current ids for next iteration - use a new array instead of trying to modify the existing one
            currentIds = currentIds.plus(nextToken.toLong())
        }
        
        // Decode the generated tokens
        return bpeTokenizer.decode(generatedIds)
    }

    private fun sampleFromLogits(logits: FloatArray, temperature: Float): Int {
        // Apply softmax and sample
        val expLogits = logits.map { Math.exp((it / temperature).toDouble()) }
        val sum = expLogits.sum()
        val probs = expLogits.map { it / sum }
        
        val random = Math.random()
        var cumsum = 0.0
        for (i in probs.indices) {
            cumsum += probs[i]
            if (random < cumsum) {
                return i
            }
        }
        
        // Fallback to argmax
        return logits.indices.maxByOrNull { logits[it] } ?: 0
    }

    // Split initialization into stages
    suspend fun initializeTokenizer() {
        // Only initialize the tokenizer first
        if (modelType == ModelType.R1_MODEL) {
            bpeTokenizer.initialize()
        }
    }

    suspend fun initializeModel() {
        // Initialize the model after tokenizer is ready
        // This can be called just before first generation
    }
}
